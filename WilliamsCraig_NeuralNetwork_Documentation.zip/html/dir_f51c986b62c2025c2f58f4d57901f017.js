var dir_f51c986b62c2025c2f58f4d57901f017 =
[
    [ "CSVParser.cs", "_c_s_v_parser_8cs.html", [
      [ "NeuralCSVManager", "class_neural_networks_1_1_kits_1_1_neural_c_s_v_manager.html", "class_neural_networks_1_1_kits_1_1_neural_c_s_v_manager" ]
    ] ],
    [ "FileManager.cs", "_file_manager_8cs.html", [
      [ "FilePath", "class_neural_networks_1_1_kits_1_1_file_path.html", "class_neural_networks_1_1_kits_1_1_file_path" ],
      [ "FileManager", "class_neural_networks_1_1_kits_1_1_file_manager.html", "class_neural_networks_1_1_kits_1_1_file_manager" ],
      [ "ES_FileLine", "struct_neural_networks_1_1_kits_1_1_file_manager_1_1_e_s___file_line.html", "struct_neural_networks_1_1_kits_1_1_file_manager_1_1_e_s___file_line" ]
    ] ],
    [ "NeuralMath.cs", "_neural_math_8cs.html", [
      [ "NeuralMath", "class_neural_networks_1_1_kits_1_1_neural_math.html", "class_neural_networks_1_1_kits_1_1_neural_math" ]
    ] ]
];