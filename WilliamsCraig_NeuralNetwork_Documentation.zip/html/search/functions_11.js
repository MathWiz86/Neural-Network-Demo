var searchData=
[
  ['vector2do_494',['Vector2Do',['../struct_neural_networks_1_1_vector2_do.html#a0459b257f2bd2c7ffd68c766f7abc70b',1,'NeuralNetworks::Vector2Do']]]
];
