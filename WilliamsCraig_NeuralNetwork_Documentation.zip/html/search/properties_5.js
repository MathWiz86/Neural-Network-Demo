var searchData=
[
  ['spritecolor_589',['SpriteColor',['../class_neural_networks_1_1_u_i_1_1_graph_point.html#ae0fb0fbc8e8fdca116c1ccdb06709000',1,'NeuralNetworks::UI::GraphPoint']]]
];
