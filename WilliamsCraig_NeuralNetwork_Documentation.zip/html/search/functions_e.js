var searchData=
[
  ['selectdisplay_471',['SelectDisplay',['../class_neural_networks_1_1_network_system.html#a726b9e1636ca37d919d84c3f6ad7711a',1,'NeuralNetworks::NetworkSystem']]],
  ['setaxesvalues_472',['SetAxesValues',['../class_neural_networks_1_1_u_i_1_1_display_graph.html#acb0cd928c6e9258ee4e5d0efc717d30d',1,'NeuralNetworks::UI::DisplayGraph']]],
  ['setbias_473',['SetBias',['../class_neural_networks_1_1_neural_network.html#acd75df9eb48ac9f7435d72309fc07bce',1,'NeuralNetworks::NeuralNetwork']]],
  ['setdata_474',['SetData',['../class_neural_networks_1_1_neural_network.html#aecacbc23bfc2a6e2049d125a2b25b8b3',1,'NeuralNetworks.NeuralNetwork.SetData(ResultsTable newData)'],['../class_neural_networks_1_1_neural_network.html#a684502049a4dfe4993e1317c7bb040d0',1,'NeuralNetworks.NeuralNetwork.SetData(ResultsData[] newData)'],['../class_neural_networks_1_1_neural_network.html#a3fe129339870c8c43d8d9013bdb1da24',1,'NeuralNetworks.NeuralNetwork.SetData(Vector2Do[] newData)']]],
  ['setderivedfunction_475',['SetDerivedFunction',['../class_neural_networks_1_1_neural_network.html#a1c838dd02f26f8053721c50101f7670b',1,'NeuralNetworks::NeuralNetwork']]],
  ['setindex_476',['SetIndex',['../struct_neural_networks_1_1_kits_1_1_file_manager_1_1_e_s___file_line.html#a75be279ad02d72162859dace820336ae',1,'NeuralNetworks::Kits::FileManager::ES_FileLine']]],
  ['setinputweight_477',['SetInputWeight',['../class_neural_networks_1_1_neural_network.html#a887eacb0913900b5428ec730f68b614f',1,'NeuralNetworks::NeuralNetwork']]],
  ['setlearningconstant_478',['SetLearningConstant',['../class_neural_networks_1_1_neural_network.html#ab5b841216d11fadce447178151079209',1,'NeuralNetworks::NeuralNetwork']]],
  ['setline_479',['SetLine',['../struct_neural_networks_1_1_kits_1_1_file_manager_1_1_e_s___file_line.html#a775ef4797dc76c192285aa2c43a2ea32',1,'NeuralNetworks::Kits::FileManager::ES_FileLine']]],
  ['setmaxerror_480',['SetMaxError',['../class_neural_networks_1_1_neural_network.html#adea5b43ee31290ca648a7c255d815dbd',1,'NeuralNetworks::NeuralNetwork']]],
  ['setmaxiterations_481',['SetMaxIterations',['../class_neural_networks_1_1_neural_network.html#a11f1d326961ecfffe5dfb5471205a8c4',1,'NeuralNetworks::NeuralNetwork']]],
  ['setmessage_482',['SetMessage',['../class_neural_networks_1_1_u_i_1_1_pop_up.html#a8699ad5706258afcacacae238af1e6d9',1,'NeuralNetworks::UI::PopUp']]],
  ['setnetworkfunctions_483',['SetNetworkFunctions',['../class_neural_networks_1_1_neural_network.html#ab34a86cb0de23a70463ac66638c623ca',1,'NeuralNetworks::NeuralNetwork']]],
  ['setneuralfunction_484',['SetNeuralFunction',['../class_neural_networks_1_1_neural_network.html#a59f17e245d326c6fd88e059ebd5c10bc',1,'NeuralNetworks::NeuralNetwork']]],
  ['setneuroncount_485',['SetNeuronCount',['../class_neural_networks_1_1_neural_network.html#a1593e56829ba09f8686c310bd4b80c5e',1,'NeuralNetworks::NeuralNetwork']]],
  ['setoutputweight_486',['SetOutputWeight',['../class_neural_networks_1_1_neural_network.html#a4c07df10a0ec0308936c4546f47c405f',1,'NeuralNetworks::NeuralNetwork']]],
  ['settitle_487',['SetTitle',['../class_neural_networks_1_1_u_i_1_1_pop_up.html#a228dee7c12d1e16f5135e75b56111360',1,'NeuralNetworks::UI::PopUp']]],
  ['setweightandbiasranges_488',['SetWeightAndBiasRanges',['../class_neural_networks_1_1_neural_network.html#a8faf8ca9ac1bc9497f77751929b6f855',1,'NeuralNetworks::NeuralNetwork']]]
];
