var searchData=
[
  ['movefile_436',['MoveFile',['../class_neural_networks_1_1_kits_1_1_file_manager.html#a0054711efc7786d4b8d1aa93006fa5c9',1,'NeuralNetworks.Kits.FileManager.MoveFile(ref string filepath_from, ref string filepath_to, bool overwrite=false, bool cleanup=false)'],['../class_neural_networks_1_1_kits_1_1_file_manager.html#a99ea02e54b5ab5ba41d5c0d5cfa8f651',1,'NeuralNetworks.Kits.FileManager.MoveFile(ref string directory_from, ref string filename_from, ref string directory_to, ref string filename_to, bool overwrite=false, bool cleanup=false)'],['../class_neural_networks_1_1_kits_1_1_file_manager.html#aa322996d9b7735e58bd82548db328c63',1,'NeuralNetworks.Kits.FileManager.MoveFile(FilePath file_from, FilePath file_to, bool overwrite=false, bool cleanup=false)']]]
];
