var searchData=
[
  ['maxerror_541',['maxError',['../class_neural_networks_1_1_neural_network.html#add3425872024a28e5b689669c0441c36',1,'NeuralNetworks::NeuralNetwork']]],
  ['maxiterations_542',['maxIterations',['../class_neural_networks_1_1_neural_network.html#ac32a35203c7cc3840920639d5647b797',1,'NeuralNetworks::NeuralNetwork']]]
];
