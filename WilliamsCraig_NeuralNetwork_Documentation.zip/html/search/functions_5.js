var searchData=
[
  ['filepath_382',['FilePath',['../class_neural_networks_1_1_kits_1_1_file_path.html#a76005f2d41084b6e5090d26574a07a00',1,'NeuralNetworks.Kits.FilePath.FilePath(string filepath, bool cleanup=true)'],['../class_neural_networks_1_1_kits_1_1_file_path.html#a048732f7d6adeddd5d68674316071e51',1,'NeuralNetworks.Kits.FilePath.FilePath(string d, string f, bool cleanup=true)']]]
];
