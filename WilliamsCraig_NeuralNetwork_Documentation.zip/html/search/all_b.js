var searchData=
[
  ['editor_164',['Editor',['../namespace_neural_networks_1_1_editor.html',1,'NeuralNetworks']]],
  ['kits_165',['Kits',['../namespace_neural_networks_1_1_kits.html',1,'NeuralNetworks']]],
  ['network_166',['network',['../class_neural_networks_1_1_network_system.html#a1534ce64c6c89a8fc3a5accfb10a3332',1,'NeuralNetworks::NetworkSystem']]],
  ['networksystem_167',['NetworkSystem',['../class_neural_networks_1_1_network_system.html',1,'NeuralNetworks']]],
  ['networksystem_2ecs_168',['NetworkSystem.cs',['../_network_system_8cs.html',1,'']]],
  ['neuralcsvmanager_169',['NeuralCSVManager',['../class_neural_networks_1_1_kits_1_1_neural_c_s_v_manager.html',1,'NeuralNetworks::Kits']]],
  ['neuralfunction_170',['neuralFunction',['../class_neural_networks_1_1_neural_network.html#a35a34bf22495a2e49b1c4dc7257151b3',1,'NeuralNetworks.NeuralNetwork.neuralFunction()'],['../class_neural_networks_1_1_neuron.html#a65735d16c8f5aeb0a0d452127a650728',1,'NeuralNetworks.Neuron.neuralFunction()'],['../class_neural_networks_1_1_network_system.html#a86b93efa0f4aa6306bc9b3674d45c24b',1,'NeuralNetworks.NetworkSystem.neuralFunction()']]],
  ['neuralmath_171',['NeuralMath',['../class_neural_networks_1_1_kits_1_1_neural_math.html',1,'NeuralNetworks.Kits.NeuralMath'],['../class_neural_networks_1_1_kits_1_1_neural_math.html#a4e64ab1526b4e58c3f0224ffe612f6a0',1,'NeuralNetworks.Kits.NeuralMath.NeuralMath()']]],
  ['neuralmath_2ecs_172',['NeuralMath.cs',['../_neural_math_8cs.html',1,'']]],
  ['neuralnetwork_173',['NeuralNetwork',['../class_neural_networks_1_1_neural_network.html',1,'NeuralNetworks.NeuralNetwork'],['../class_neural_networks_1_1_neural_network.html#a4a712a23a4e8235fefb58d7212d36e7d',1,'NeuralNetworks.NeuralNetwork.NeuralNetwork(System.Func&lt; double, double &gt; neuralFunction, System.Func&lt; double, double &gt; derivedFunction)'],['../class_neural_networks_1_1_neural_network.html#ab642c71206dfefb96e7db23bf2bb38f9',1,'NeuralNetworks.NeuralNetwork.NeuralNetwork(System.Func&lt; double, double &gt; neuralFunction, System.Func&lt; double, double &gt; derivedFunction, double learningConstant, int neuronCount, int maxIterations, double maxError)']]],
  ['neuralnetwork_2ecs_174',['NeuralNetwork.cs',['../_neural_network_8cs.html',1,'']]],
  ['neuralnetworks_175',['NeuralNetworks',['../namespace_neural_networks.html',1,'']]],
  ['neuron_176',['Neuron',['../class_neural_networks_1_1_neuron.html',1,'NeuralNetworks.Neuron'],['../class_neural_networks_1_1_neuron.html#ac34893d945228ce899389910a84b2ae2',1,'NeuralNetworks.Neuron.Neuron()']]],
  ['neuron_2ecs_177',['Neuron.cs',['../_neuron_8cs.html',1,'']]],
  ['neuroncount_178',['neuronCount',['../class_neural_networks_1_1_neural_network.html#a362b801dfd378390b4401633380a9668',1,'NeuralNetworks::NeuralNetwork']]],
  ['neurons_179',['neurons',['../class_neural_networks_1_1_neural_network.html#af25158e6dca4bc3276b08c299aa1a594',1,'NeuralNetworks::NeuralNetwork']]],
  ['normalcolor_180',['NormalColor',['../class_neural_networks_1_1_u_i_1_1_result_data_display.html#aa2b8a983ba3cc06c628b5fc3f0a01055',1,'NeuralNetworks::UI::ResultDataDisplay']]],
  ['ui_181',['UI',['../namespace_neural_networks_1_1_u_i.html',1,'NeuralNetworks']]]
];
