var searchData=
[
  ['lasterror_587',['LastError',['../class_neural_networks_1_1_neural_network.html#aa18b4e99cabe7a53d76e75f088509fa4',1,'NeuralNetworks::NeuralNetwork']]],
  ['line_588',['line',['../struct_neural_networks_1_1_kits_1_1_file_manager_1_1_e_s___file_line.html#aae1215af5f73f7c13555c8ae0a36b930',1,'NeuralNetworks::Kits::FileManager::ES_FileLine']]]
];
