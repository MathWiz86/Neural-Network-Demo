var searchData=
[
  ['selectedcolor_563',['SelectedColor',['../class_neural_networks_1_1_u_i_1_1_result_data_display.html#a11d9d63dc040614a6918d18cfc0134b5',1,'NeuralNetworks::UI::ResultDataDisplay']]],
  ['selecteddisplay_564',['selectedDisplay',['../class_neural_networks_1_1_network_system.html#a8c944ac06868bb81068447e70e4e0939',1,'NeuralNetworks::NetworkSystem']]],
  ['singleton_565',['singleton',['../class_neural_networks_1_1_network_system.html#a33375d895f4fc38565d6638b0f796fff',1,'NeuralNetworks.NetworkSystem.singleton()'],['../class_neural_networks_1_1_u_i_1_1_pop_up_system.html#aa664d1c706ee83dc727cb4313d7a1012',1,'NeuralNetworks.UI.PopUpSystem.singleton()']]],
  ['standardtitlebar_566',['StandardTitleBar',['../class_neural_networks_1_1_kits_1_1_neural_c_s_v_manager.html#a6dcd9da466c1d774017f5d4c739800eb',1,'NeuralNetworks::Kits::NeuralCSVManager']]],
  ['startbias_567',['startBias',['../class_neural_networks_1_1_neuron.html#a87cd8be2acae97faa38c20ef5bf6da20',1,'NeuralNetworks::Neuron']]],
  ['startinputweight_568',['startInputWeight',['../class_neural_networks_1_1_neuron.html#a916c92d0f0bc2522fa606ec808ac8487',1,'NeuralNetworks::Neuron']]],
  ['startoutputweight_569',['startOutputWeight',['../class_neural_networks_1_1_neuron.html#a572bc11325d842cf34237592f7eddcd2',1,'NeuralNetworks::Neuron']]]
];
