var searchData=
[
  ['data_518',['data',['../class_neural_networks_1_1_neural_network.html#a5a3100b8a4264c6f8c98dc3749e83466',1,'NeuralNetworks.NeuralNetwork.data()'],['../class_neural_networks_1_1_results_table.html#a3a049e0fed85983d66703aa636b836e0',1,'NeuralNetworks.ResultsTable.data()']]],
  ['derivedfunction_519',['derivedFunction',['../class_neural_networks_1_1_neural_network.html#a2177eb02652fd9a24ed01b0c9a64fe4a',1,'NeuralNetworks.NeuralNetwork.derivedFunction()'],['../class_neural_networks_1_1_neuron.html#a9962b43f2eac85d35c76024fde3222dd',1,'NeuralNetworks.Neuron.derivedFunction()'],['../class_neural_networks_1_1_network_system.html#afc609df907cb9aeaf2f73694fa46e449',1,'NeuralNetworks.NetworkSystem.derivedFunction()']]],
  ['directory_520',['directory',['../class_neural_networks_1_1_kits_1_1_file_path.html#a22252a4e5fe7546415747136a3e59732',1,'NeuralNetworks::Kits::FilePath']]],
  ['displayparent_521',['displayParent',['../class_neural_networks_1_1_network_system.html#a3be7b8a98949f18f7e4bda904e90ee27',1,'NeuralNetworks::NetworkSystem']]],
  ['displayprefab_522',['displayPrefab',['../class_neural_networks_1_1_network_system.html#a9ea1eb7a5514732a6b15144293821360',1,'NeuralNetworks::NetworkSystem']]]
];
