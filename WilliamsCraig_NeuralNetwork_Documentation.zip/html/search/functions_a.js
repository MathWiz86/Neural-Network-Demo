var searchData=
[
  ['neuralmath_437',['NeuralMath',['../class_neural_networks_1_1_kits_1_1_neural_math.html#a4e64ab1526b4e58c3f0224ffe612f6a0',1,'NeuralNetworks::Kits::NeuralMath']]],
  ['neuralnetwork_438',['NeuralNetwork',['../class_neural_networks_1_1_neural_network.html#a4a712a23a4e8235fefb58d7212d36e7d',1,'NeuralNetworks.NeuralNetwork.NeuralNetwork(System.Func&lt; double, double &gt; neuralFunction, System.Func&lt; double, double &gt; derivedFunction)'],['../class_neural_networks_1_1_neural_network.html#ab642c71206dfefb96e7db23bf2bb38f9',1,'NeuralNetworks.NeuralNetwork.NeuralNetwork(System.Func&lt; double, double &gt; neuralFunction, System.Func&lt; double, double &gt; derivedFunction, double learningConstant, int neuronCount, int maxIterations, double maxError)']]],
  ['neuron_439',['Neuron',['../class_neural_networks_1_1_neuron.html#ac34893d945228ce899389910a84b2ae2',1,'NeuralNetworks::Neuron']]]
];
