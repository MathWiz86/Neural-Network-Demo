var searchData=
[
  ['comrecttransform_583',['ComRectTransform',['../class_neural_networks_1_1_u_i_1_1_graph_axis_value.html#a6909619338cd30c06cea1c6e3d167e2c',1,'NeuralNetworks.UI.GraphAxisValue.ComRectTransform()'],['../class_neural_networks_1_1_u_i_1_1_graph_point.html#a0aa3fa504312862c7098c1da4624a5a0',1,'NeuralNetworks.UI.GraphPoint.ComRectTransform()']]]
];
