var searchData=
[
  ['deletefile_377',['DeleteFile',['../class_neural_networks_1_1_kits_1_1_file_manager.html#a5021422fcd750d19390709edd058c905',1,'NeuralNetworks.Kits.FileManager.DeleteFile(ref string filepath, bool cleanup=false)'],['../class_neural_networks_1_1_kits_1_1_file_manager.html#a43ff2b8bfce6297db6c00eb6dd3b39e5',1,'NeuralNetworks.Kits.FileManager.DeleteFile(ref string directory, ref string filename, bool cleanup=false)'],['../class_neural_networks_1_1_kits_1_1_file_manager.html#ad319be5d240e67c27d37a4219db6ed72',1,'NeuralNetworks.Kits.FileManager.DeleteFile(FilePath file, bool cleanup=false)']]],
  ['destroycurrentpopup_378',['DestroyCurrentPopup',['../class_neural_networks_1_1_u_i_1_1_pop_up_system.html#a3a40adb43d4045236b5143b7edcb41d7',1,'NeuralNetworks::UI::PopUpSystem']]]
];
