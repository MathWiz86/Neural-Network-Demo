var searchData=
[
  ['onexpectedoutputchanged_440',['OnExpectedOutputChanged',['../class_neural_networks_1_1_u_i_1_1_result_data_display.html#a40ae24322bf13a4350d040256cb25634',1,'NeuralNetworks::UI::ResultDataDisplay']]],
  ['ongui_441',['OnGUI',['../class_neural_networks_1_1_editor_1_1_results_data_drawer.html#a748873bdea9b1cf92553a21391844913',1,'NeuralNetworks.Editor.ResultsDataDrawer.OnGUI()'],['../class_neural_networks_1_1_editor_1_1_results_table_drawer.html#adfabf5891d9ec7826f5ba7c6f3ce7298',1,'NeuralNetworks.Editor.ResultsTableDrawer.OnGUI()'],['../class_neural_networks_1_1_editor_1_1_vector2_do_drawer.html#a5cf9700ad7015a3917d77aaea78f0b72',1,'NeuralNetworks.Editor.Vector2DoDrawer.OnGUI()']]],
  ['oninputchanged_442',['OnInputChanged',['../class_neural_networks_1_1_u_i_1_1_result_data_display.html#a7238e2dfd9bd074a9030832788788310',1,'NeuralNetworks::UI::ResultDataDisplay']]],
  ['onpointerclick_443',['OnPointerClick',['../class_neural_networks_1_1_u_i_1_1_result_data_display.html#a615890bf217f565b53608a2c4cae8ece',1,'NeuralNetworks::UI::ResultDataDisplay']]],
  ['onpointerenter_444',['OnPointerEnter',['../class_neural_networks_1_1_u_i_1_1_graph_point.html#ac3bf800cfc4310edea9950e006b15c27',1,'NeuralNetworks::UI::GraphPoint']]],
  ['onpointerexit_445',['OnPointerExit',['../class_neural_networks_1_1_u_i_1_1_graph_point.html#ad5da123ac3ca092542044b89718e4917',1,'NeuralNetworks::UI::GraphPoint']]],
  ['onvaluechanged_446',['OnValueChanged',['../class_neural_networks_1_1_u_i_1_1_value_slider.html#ac70fc8193b56543ac46af2d02018e824',1,'NeuralNetworks::UI::ValueSlider']]],
  ['options_5fautosave_447',['Options_AutoSave',['../class_neural_networks_1_1_network_system.html#a9faaf2bb8c27000fe26b874464edec5b',1,'NeuralNetworks::NetworkSystem']]],
  ['options_5fiterations_448',['Options_Iterations',['../class_neural_networks_1_1_network_system.html#a8bd143869ebe7e00ff8c47dbd83e3201',1,'NeuralNetworks::NetworkSystem']]],
  ['options_5flearningspeed_449',['Options_LearningSpeed',['../class_neural_networks_1_1_network_system.html#afcffd6316678efbfeee83aee44527700',1,'NeuralNetworks::NetworkSystem']]],
  ['options_5fmaxerror_450',['Options_MaxError',['../class_neural_networks_1_1_network_system.html#a05312fd181218568c914314227811e1d',1,'NeuralNetworks::NetworkSystem']]],
  ['options_5fneuroncount_451',['Options_NeuronCount',['../class_neural_networks_1_1_network_system.html#a71bbb13a61a4ea334abf2e38446347a7',1,'NeuralNetworks::NetworkSystem']]]
];
