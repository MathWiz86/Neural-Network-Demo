var searchData=
[
  ['writeneuraldatatofile_284',['WriteNeuralDataToFile',['../class_neural_networks_1_1_kits_1_1_neural_c_s_v_manager.html#a39ecaadf1fd633eb74bb66ff93a943f2',1,'NeuralNetworks::Kits::NeuralCSVManager']]]
];
