var searchData=
[
  ['background_502',['background',['../class_neural_networks_1_1_u_i_1_1_result_data_display.html#a270b33a70118b5dabd3d4a4168a1d29d',1,'NeuralNetworks::UI::ResultDataDisplay']]],
  ['basicdatacount_503',['BasicDataCount',['../class_neural_networks_1_1_network_system.html#ab3f8ce3d2e33a02e02175cd5c04b8a51',1,'NeuralNetworks::NetworkSystem']]],
  ['biasrange_504',['biasRange',['../class_neural_networks_1_1_neural_network.html#ad4ba1ef0becffdab4957bcaebf83890a',1,'NeuralNetworks::NeuralNetwork']]],
  ['buremoveelement_505',['buRemoveElement',['../class_neural_networks_1_1_network_system.html#a13bd5dbb366fe5222683a5f04ce64549',1,'NeuralNetworks::NetworkSystem']]],
  ['button_506',['button',['../struct_neural_networks_1_1_u_i_1_1_pop_up_1_1_pop_up_button.html#a62e7beadac7dddedc23e1e13dce3d9ce',1,'NeuralNetworks::UI::PopUp::PopUpButton']]],
  ['buttons_507',['buttons',['../class_neural_networks_1_1_u_i_1_1_pop_up.html#aaaba586499d9cd2cc335dffd4e58928b',1,'NeuralNetworks::UI::PopUp']]]
];
