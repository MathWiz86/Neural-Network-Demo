var searchData=
[
  ['maxerror_161',['maxError',['../class_neural_networks_1_1_neural_network.html#add3425872024a28e5b689669c0441c36',1,'NeuralNetworks::NeuralNetwork']]],
  ['maxiterations_162',['maxIterations',['../class_neural_networks_1_1_neural_network.html#ac32a35203c7cc3840920639d5647b797',1,'NeuralNetworks::NeuralNetwork']]],
  ['movefile_163',['MoveFile',['../class_neural_networks_1_1_kits_1_1_file_manager.html#a0054711efc7786d4b8d1aa93006fa5c9',1,'NeuralNetworks.Kits.FileManager.MoveFile(ref string filepath_from, ref string filepath_to, bool overwrite=false, bool cleanup=false)'],['../class_neural_networks_1_1_kits_1_1_file_manager.html#a99ea02e54b5ab5ba41d5c0d5cfa8f651',1,'NeuralNetworks.Kits.FileManager.MoveFile(ref string directory_from, ref string filename_from, ref string directory_to, ref string filename_to, bool overwrite=false, bool cleanup=false)'],['../class_neural_networks_1_1_kits_1_1_file_manager.html#aa322996d9b7735e58bd82548db328c63',1,'NeuralNetworks.Kits.FileManager.MoveFile(FilePath file_from, FilePath file_to, bool overwrite=false, bool cleanup=false)']]]
];
