var searchData=
[
  ['data_66',['data',['../class_neural_networks_1_1_neural_network.html#a5a3100b8a4264c6f8c98dc3749e83466',1,'NeuralNetworks.NeuralNetwork.data()'],['../class_neural_networks_1_1_results_table.html#a3a049e0fed85983d66703aa636b836e0',1,'NeuralNetworks.ResultsTable.data()']]],
  ['deletefile_67',['DeleteFile',['../class_neural_networks_1_1_kits_1_1_file_manager.html#a5021422fcd750d19390709edd058c905',1,'NeuralNetworks.Kits.FileManager.DeleteFile(ref string filepath, bool cleanup=false)'],['../class_neural_networks_1_1_kits_1_1_file_manager.html#a43ff2b8bfce6297db6c00eb6dd3b39e5',1,'NeuralNetworks.Kits.FileManager.DeleteFile(ref string directory, ref string filename, bool cleanup=false)'],['../class_neural_networks_1_1_kits_1_1_file_manager.html#ad319be5d240e67c27d37a4219db6ed72',1,'NeuralNetworks.Kits.FileManager.DeleteFile(FilePath file, bool cleanup=false)']]],
  ['derivedfunction_68',['derivedFunction',['../class_neural_networks_1_1_neural_network.html#a2177eb02652fd9a24ed01b0c9a64fe4a',1,'NeuralNetworks.NeuralNetwork.derivedFunction()'],['../class_neural_networks_1_1_neuron.html#a9962b43f2eac85d35c76024fde3222dd',1,'NeuralNetworks.Neuron.derivedFunction()'],['../class_neural_networks_1_1_network_system.html#afc609df907cb9aeaf2f73694fa46e449',1,'NeuralNetworks.NetworkSystem.derivedFunction()']]],
  ['destroycurrentpopup_69',['DestroyCurrentPopup',['../class_neural_networks_1_1_u_i_1_1_pop_up_system.html#a3a40adb43d4045236b5143b7edcb41d7',1,'NeuralNetworks::UI::PopUpSystem']]],
  ['directory_70',['directory',['../class_neural_networks_1_1_kits_1_1_file_path.html#a22252a4e5fe7546415747136a3e59732',1,'NeuralNetworks::Kits::FilePath']]],
  ['displayeddata_71',['DisplayedData',['../class_neural_networks_1_1_u_i_1_1_result_data_display.html#af81a368fdbdca1e91ce4a39793cc29e3',1,'NeuralNetworks::UI::ResultDataDisplay']]],
  ['displaygraph_72',['DisplayGraph',['../class_neural_networks_1_1_u_i_1_1_display_graph.html',1,'NeuralNetworks::UI']]],
  ['displaygraph_2ecs_73',['DisplayGraph.cs',['../_display_graph_8cs.html',1,'']]],
  ['displayparent_74',['displayParent',['../class_neural_networks_1_1_network_system.html#a3be7b8a98949f18f7e4bda904e90ee27',1,'NeuralNetworks::NetworkSystem']]],
  ['displayprefab_75',['displayPrefab',['../class_neural_networks_1_1_network_system.html#a9ea1eb7a5514732a6b15144293821360',1,'NeuralNetworks::NetworkSystem']]]
];
