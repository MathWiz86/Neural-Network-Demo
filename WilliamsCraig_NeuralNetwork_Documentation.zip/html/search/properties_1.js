var searchData=
[
  ['displayeddata_584',['DisplayedData',['../class_neural_networks_1_1_u_i_1_1_result_data_display.html#af81a368fdbdca1e91ce4a39793cc29e3',1,'NeuralNetworks::UI::ResultDataDisplay']]]
];
