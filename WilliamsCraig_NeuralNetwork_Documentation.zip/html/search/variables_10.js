var searchData=
[
  ['x_577',['x',['../struct_neural_networks_1_1_vector2_do.html#ad42618c45256a03e535380dbc0ea4e03',1,'NeuralNetworks::Vector2Do']]],
  ['xaxisvalues_578',['xAxisValues',['../class_neural_networks_1_1_u_i_1_1_display_graph.html#a34ca67aad2603d4bec0adfcf73b52dd4',1,'NeuralNetworks::UI::DisplayGraph']]],
  ['xsections_579',['xSections',['../class_neural_networks_1_1_u_i_1_1_display_graph.html#a6e834274d442481b14f1ebe37553b029',1,'NeuralNetworks::UI::DisplayGraph']]]
];
