var dir_96672db471a9bbeb282538d483fd0c09 =
[
    [ "NetworkSystem.cs", "_network_system_8cs.html", [
      [ "NetworkSystem", "class_neural_networks_1_1_network_system.html", "class_neural_networks_1_1_network_system" ]
    ] ],
    [ "PopUpSystem.cs", "_pop_up_system_8cs.html", [
      [ "PopUpSystem", "class_neural_networks_1_1_u_i_1_1_pop_up_system.html", "class_neural_networks_1_1_u_i_1_1_pop_up_system" ]
    ] ]
];