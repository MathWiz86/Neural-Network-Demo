var hierarchy =
[
    [ "NeuralNetworks.Kits.FileManager.ES_FileLine", "struct_neural_networks_1_1_kits_1_1_file_manager_1_1_e_s___file_line.html", null ],
    [ "NeuralNetworks.Kits.FileManager", "class_neural_networks_1_1_kits_1_1_file_manager.html", null ],
    [ "NeuralNetworks.Kits.FilePath", "class_neural_networks_1_1_kits_1_1_file_path.html", null ],
    [ "IPointerClickHandler", null, [
      [ "NeuralNetworks.UI.ResultDataDisplay", "class_neural_networks_1_1_u_i_1_1_result_data_display.html", null ]
    ] ],
    [ "IPointerEnterHandler", null, [
      [ "NeuralNetworks.UI.GraphPoint", "class_neural_networks_1_1_u_i_1_1_graph_point.html", null ]
    ] ],
    [ "IPointerExitHandler", null, [
      [ "NeuralNetworks.UI.GraphPoint", "class_neural_networks_1_1_u_i_1_1_graph_point.html", null ]
    ] ],
    [ "MonoBehaviour", null, [
      [ "NeuralNetworks.NetworkSystem", "class_neural_networks_1_1_network_system.html", null ],
      [ "NeuralNetworks.UI.DisplayGraph", "class_neural_networks_1_1_u_i_1_1_display_graph.html", null ],
      [ "NeuralNetworks.UI.GraphAxisValue", "class_neural_networks_1_1_u_i_1_1_graph_axis_value.html", null ],
      [ "NeuralNetworks.UI.GraphPoint", "class_neural_networks_1_1_u_i_1_1_graph_point.html", null ],
      [ "NeuralNetworks.UI.PopUp", "class_neural_networks_1_1_u_i_1_1_pop_up.html", null ],
      [ "NeuralNetworks.UI.PopUpSystem", "class_neural_networks_1_1_u_i_1_1_pop_up_system.html", null ],
      [ "NeuralNetworks.UI.ResultDataDisplay", "class_neural_networks_1_1_u_i_1_1_result_data_display.html", null ],
      [ "NeuralNetworks.UI.ValueSlider", "class_neural_networks_1_1_u_i_1_1_value_slider.html", null ]
    ] ],
    [ "NeuralNetworks.Kits.NeuralCSVManager", "class_neural_networks_1_1_kits_1_1_neural_c_s_v_manager.html", null ],
    [ "NeuralNetworks.Kits.NeuralMath", "class_neural_networks_1_1_kits_1_1_neural_math.html", null ],
    [ "NeuralNetworks.NeuralNetwork", "class_neural_networks_1_1_neural_network.html", null ],
    [ "NeuralNetworks.Neuron", "class_neural_networks_1_1_neuron.html", null ],
    [ "NeuralNetworks.UI.PopUp.PopUpButton", "struct_neural_networks_1_1_u_i_1_1_pop_up_1_1_pop_up_button.html", null ],
    [ "PropertyDrawer", null, [
      [ "NeuralNetworks.Editor.ResultsDataDrawer", "class_neural_networks_1_1_editor_1_1_results_data_drawer.html", null ],
      [ "NeuralNetworks.Editor.ResultsTableDrawer", "class_neural_networks_1_1_editor_1_1_results_table_drawer.html", null ],
      [ "NeuralNetworks.Editor.Vector2DoDrawer", "class_neural_networks_1_1_editor_1_1_vector2_do_drawer.html", null ]
    ] ],
    [ "NeuralNetworks.ResultsData", "class_neural_networks_1_1_results_data.html", null ],
    [ "NeuralNetworks.ResultsTable", "class_neural_networks_1_1_results_table.html", null ],
    [ "NeuralNetworks.Vector2Do", "struct_neural_networks_1_1_vector2_do.html", null ]
];