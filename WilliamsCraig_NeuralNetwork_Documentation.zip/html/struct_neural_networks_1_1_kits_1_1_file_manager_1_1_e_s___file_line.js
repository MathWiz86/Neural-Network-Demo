var struct_neural_networks_1_1_kits_1_1_file_manager_1_1_e_s___file_line =
[
    [ "ES_FileLine", "struct_neural_networks_1_1_kits_1_1_file_manager_1_1_e_s___file_line.html#af008c5fcc37bf5bf35b71d582ad7c3d7", null ],
    [ "SetIndex", "struct_neural_networks_1_1_kits_1_1_file_manager_1_1_e_s___file_line.html#a75be279ad02d72162859dace820336ae", null ],
    [ "SetLine", "struct_neural_networks_1_1_kits_1_1_file_manager_1_1_e_s___file_line.html#a775ef4797dc76c192285aa2c43a2ea32", null ],
    [ "index", "struct_neural_networks_1_1_kits_1_1_file_manager_1_1_e_s___file_line.html#a3046661bc0a6da619b9ac1b01d630cf9", null ],
    [ "line", "struct_neural_networks_1_1_kits_1_1_file_manager_1_1_e_s___file_line.html#aae1215af5f73f7c13555c8ae0a36b930", null ]
];