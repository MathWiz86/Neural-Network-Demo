var class_neural_networks_1_1_editor_1_1_results_data_drawer =
[
    [ "GetPropertyHeight", "class_neural_networks_1_1_editor_1_1_results_data_drawer.html#af61fc560c08de19b65bec2fd915126b2", null ],
    [ "OnGUI", "class_neural_networks_1_1_editor_1_1_results_data_drawer.html#a748873bdea9b1cf92553a21391844913", null ]
];