var dir_aedb39439b18d68cc3bff1bdb3e614b5 =
[
    [ "DisplayGraph.cs", "_display_graph_8cs.html", [
      [ "DisplayGraph", "class_neural_networks_1_1_u_i_1_1_display_graph.html", "class_neural_networks_1_1_u_i_1_1_display_graph" ]
    ] ],
    [ "GraphAxisValue.cs", "_graph_axis_value_8cs.html", [
      [ "GraphAxisValue", "class_neural_networks_1_1_u_i_1_1_graph_axis_value.html", "class_neural_networks_1_1_u_i_1_1_graph_axis_value" ]
    ] ],
    [ "GraphPoint.cs", "_graph_point_8cs.html", [
      [ "GraphPoint", "class_neural_networks_1_1_u_i_1_1_graph_point.html", "class_neural_networks_1_1_u_i_1_1_graph_point" ]
    ] ]
];