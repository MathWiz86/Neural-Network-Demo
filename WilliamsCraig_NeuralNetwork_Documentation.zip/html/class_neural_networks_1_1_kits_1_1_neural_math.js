var class_neural_networks_1_1_kits_1_1_neural_math =
[
    [ "NeuralMath", "class_neural_networks_1_1_kits_1_1_neural_math.html#a4e64ab1526b4e58c3f0224ffe612f6a0", null ],
    [ "GetRandomDoubleIE", "class_neural_networks_1_1_kits_1_1_neural_math.html#a69ed63b4ff311fac878ef45ef00c8d02", null ],
    [ "ResetGenerator", "class_neural_networks_1_1_kits_1_1_neural_math.html#ad1eb00ca852c9bc30fce5a6b6d88f803", null ],
    [ "ResetGenerator", "class_neural_networks_1_1_kits_1_1_neural_math.html#a398e00aeea0cc01bcc159e23f84493a5", null ],
    [ "Generator", "class_neural_networks_1_1_kits_1_1_neural_math.html#af0259c1c0fda1fc57e6fb0c37e4bf81a", null ]
];