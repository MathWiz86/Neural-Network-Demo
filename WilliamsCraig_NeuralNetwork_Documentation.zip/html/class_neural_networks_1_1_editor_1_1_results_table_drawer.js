var class_neural_networks_1_1_editor_1_1_results_table_drawer =
[
    [ "GetPropertyHeight", "class_neural_networks_1_1_editor_1_1_results_table_drawer.html#a4f9eb21c17d2150112750f6c1ce2b64b", null ],
    [ "OnGUI", "class_neural_networks_1_1_editor_1_1_results_table_drawer.html#adfabf5891d9ec7826f5ba7c6f3ce7298", null ]
];