var struct_neural_networks_1_1_vector2_do =
[
    [ "Vector2Do", "struct_neural_networks_1_1_vector2_do.html#a0459b257f2bd2c7ffd68c766f7abc70b", null ],
    [ "x", "struct_neural_networks_1_1_vector2_do.html#ad42618c45256a03e535380dbc0ea4e03", null ],
    [ "y", "struct_neural_networks_1_1_vector2_do.html#a880f39f9bbb9a54df1d8bb8b9747c77b", null ]
];