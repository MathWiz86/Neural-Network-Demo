var class_neural_networks_1_1_results_data =
[
    [ "ResultsData", "class_neural_networks_1_1_results_data.html#a2da32d08684524c7f4995ce26937f71f", null ],
    [ "ResultsData", "class_neural_networks_1_1_results_data.html#ac3d959409ea7ce05b3b15d7fe56b042e", null ],
    [ "ResultsData", "class_neural_networks_1_1_results_data.html#af8a7ee02bc7ffded3d07d68aac5c381d", null ],
    [ "ResultsData", "class_neural_networks_1_1_results_data.html#ac348c502d6f99c5794f515581eb23efa", null ],
    [ "ActualOutput", "class_neural_networks_1_1_results_data.html#aa6307e33d6a93486b4931d0c4472c40a", null ],
    [ "ExpectedOutput", "class_neural_networks_1_1_results_data.html#a3bdcb936355cea2e6e7d4801f72e681c", null ],
    [ "Input", "class_neural_networks_1_1_results_data.html#a6ae21193cb8aff64b5d00e88ca31ef28", null ]
];