var class_neural_networks_1_1_u_i_1_1_pop_up =
[
    [ "PopUpButton", "struct_neural_networks_1_1_u_i_1_1_pop_up_1_1_pop_up_button.html", "struct_neural_networks_1_1_u_i_1_1_pop_up_1_1_pop_up_button" ],
    [ "InitializeButton", "class_neural_networks_1_1_u_i_1_1_pop_up.html#a8146f6630e6cd4450fc7cac030096c8e", null ],
    [ "SetMessage", "class_neural_networks_1_1_u_i_1_1_pop_up.html#a8699ad5706258afcacacae238af1e6d9", null ],
    [ "SetTitle", "class_neural_networks_1_1_u_i_1_1_pop_up.html#a228dee7c12d1e16f5135e75b56111360", null ],
    [ "buttons", "class_neural_networks_1_1_u_i_1_1_pop_up.html#aaaba586499d9cd2cc335dffd4e58928b", null ],
    [ "tmpMessage", "class_neural_networks_1_1_u_i_1_1_pop_up.html#a769b980b9fdbf512e5bd35e4457c0ebb", null ],
    [ "tmpTitle", "class_neural_networks_1_1_u_i_1_1_pop_up.html#af22e3b6046a76d84b86f07f5121adccb", null ]
];