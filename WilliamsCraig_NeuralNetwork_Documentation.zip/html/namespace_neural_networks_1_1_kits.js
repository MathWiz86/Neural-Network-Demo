var namespace_neural_networks_1_1_kits =
[
    [ "FileManager", "class_neural_networks_1_1_kits_1_1_file_manager.html", "class_neural_networks_1_1_kits_1_1_file_manager" ],
    [ "FilePath", "class_neural_networks_1_1_kits_1_1_file_path.html", "class_neural_networks_1_1_kits_1_1_file_path" ],
    [ "NeuralCSVManager", "class_neural_networks_1_1_kits_1_1_neural_c_s_v_manager.html", "class_neural_networks_1_1_kits_1_1_neural_c_s_v_manager" ],
    [ "NeuralMath", "class_neural_networks_1_1_kits_1_1_neural_math.html", "class_neural_networks_1_1_kits_1_1_neural_math" ]
];