var namespace_neural_networks =
[
    [ "Editor", "namespace_neural_networks_1_1_editor.html", "namespace_neural_networks_1_1_editor" ],
    [ "Kits", "namespace_neural_networks_1_1_kits.html", "namespace_neural_networks_1_1_kits" ],
    [ "UI", "namespace_neural_networks_1_1_u_i.html", "namespace_neural_networks_1_1_u_i" ],
    [ "NetworkSystem", "class_neural_networks_1_1_network_system.html", "class_neural_networks_1_1_network_system" ],
    [ "NeuralNetwork", "class_neural_networks_1_1_neural_network.html", "class_neural_networks_1_1_neural_network" ],
    [ "Neuron", "class_neural_networks_1_1_neuron.html", "class_neural_networks_1_1_neuron" ],
    [ "ResultsData", "class_neural_networks_1_1_results_data.html", "class_neural_networks_1_1_results_data" ],
    [ "ResultsTable", "class_neural_networks_1_1_results_table.html", "class_neural_networks_1_1_results_table" ],
    [ "Vector2Do", "struct_neural_networks_1_1_vector2_do.html", "struct_neural_networks_1_1_vector2_do" ]
];