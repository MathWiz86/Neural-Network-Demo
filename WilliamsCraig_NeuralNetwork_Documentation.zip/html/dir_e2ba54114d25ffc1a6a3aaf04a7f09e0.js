var dir_e2ba54114d25ffc1a6a3aaf04a7f09e0 =
[
    [ "NeuralNetwork.cs", "_neural_network_8cs.html", [
      [ "NeuralNetwork", "class_neural_networks_1_1_neural_network.html", "class_neural_networks_1_1_neural_network" ]
    ] ],
    [ "Neuron.cs", "_neuron_8cs.html", [
      [ "Neuron", "class_neural_networks_1_1_neuron.html", "class_neural_networks_1_1_neuron" ]
    ] ],
    [ "ResultsTable.cs", "_results_table_8cs.html", [
      [ "Vector2Do", "struct_neural_networks_1_1_vector2_do.html", "struct_neural_networks_1_1_vector2_do" ],
      [ "ResultsData", "class_neural_networks_1_1_results_data.html", "class_neural_networks_1_1_results_data" ],
      [ "ResultsTable", "class_neural_networks_1_1_results_table.html", "class_neural_networks_1_1_results_table" ]
    ] ]
];