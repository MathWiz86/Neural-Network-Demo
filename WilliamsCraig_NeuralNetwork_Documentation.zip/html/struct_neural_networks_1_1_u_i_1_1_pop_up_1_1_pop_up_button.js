var struct_neural_networks_1_1_u_i_1_1_pop_up_1_1_pop_up_button =
[
    [ "button", "struct_neural_networks_1_1_u_i_1_1_pop_up_1_1_pop_up_button.html#a62e7beadac7dddedc23e1e13dce3d9ce", null ],
    [ "tmpTitle", "struct_neural_networks_1_1_u_i_1_1_pop_up_1_1_pop_up_button.html#acee195876a7a25f1362b096e24762ba4", null ]
];