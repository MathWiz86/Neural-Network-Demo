var class_neural_networks_1_1_u_i_1_1_result_data_display =
[
    [ "InitializeDisplay", "class_neural_networks_1_1_u_i_1_1_result_data_display.html#a8acd642df86c36b2a62b913ef8a85495", null ],
    [ "OnExpectedOutputChanged", "class_neural_networks_1_1_u_i_1_1_result_data_display.html#a40ae24322bf13a4350d040256cb25634", null ],
    [ "OnInputChanged", "class_neural_networks_1_1_u_i_1_1_result_data_display.html#a7238e2dfd9bd074a9030832788788310", null ],
    [ "OnPointerClick", "class_neural_networks_1_1_u_i_1_1_result_data_display.html#a615890bf217f565b53608a2c4cae8ece", null ],
    [ "ReturnToNormalColor", "class_neural_networks_1_1_u_i_1_1_result_data_display.html#a30bc07fdadd103be41b88097f23f71d2", null ],
    [ "UpdateDisplay", "class_neural_networks_1_1_u_i_1_1_result_data_display.html#ac07e3ed1afb4988dc9fa916f1c047977", null ],
    [ "acoutputField", "class_neural_networks_1_1_u_i_1_1_result_data_display.html#a0b01b2796dbf7528b17d53097a120ef0", null ],
    [ "background", "class_neural_networks_1_1_u_i_1_1_result_data_display.html#a270b33a70118b5dabd3d4a4168a1d29d", null ],
    [ "exoutputField", "class_neural_networks_1_1_u_i_1_1_result_data_display.html#a3dfa87ed50992d78d39e0354e544c712", null ],
    [ "inputField", "class_neural_networks_1_1_u_i_1_1_result_data_display.html#a3fb4aae78b12892ce3037a85212ba96e", null ],
    [ "NormalColor", "class_neural_networks_1_1_u_i_1_1_result_data_display.html#aa2b8a983ba3cc06c628b5fc3f0a01055", null ],
    [ "SelectedColor", "class_neural_networks_1_1_u_i_1_1_result_data_display.html#a11d9d63dc040614a6918d18cfc0134b5", null ],
    [ "DisplayedData", "class_neural_networks_1_1_u_i_1_1_result_data_display.html#af81a368fdbdca1e91ce4a39793cc29e3", null ]
];